
namespace HW_SI
{
	void Initialize();
};