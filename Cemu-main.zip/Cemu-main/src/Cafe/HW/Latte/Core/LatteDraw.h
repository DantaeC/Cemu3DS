#pragma once
#include "Common/GLInclude/GLInclude.h"

void LatteDraw_cleanupAfterFrame();