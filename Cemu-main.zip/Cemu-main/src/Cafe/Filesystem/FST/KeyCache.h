#pragma once

void KeyCache_Prepare();

uint8* KeyCache_GetAES128(sint32 index);