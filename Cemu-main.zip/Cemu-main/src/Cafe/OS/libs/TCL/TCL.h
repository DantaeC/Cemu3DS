namespace TCL
{
	void Initialize();
}