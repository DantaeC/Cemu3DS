namespace coreinit
{
	void InitializeHWInterface();
};