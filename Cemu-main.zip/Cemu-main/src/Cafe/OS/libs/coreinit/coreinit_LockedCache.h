#pragma once

namespace coreinit
{
	void InitializeLC();
}