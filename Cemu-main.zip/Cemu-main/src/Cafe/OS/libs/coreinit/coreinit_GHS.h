#pragma once

namespace coreinit
{
	void PrepareGHSRuntime();

	void InitializeGHS();
};