#pragma once

namespace coreinit
{
	void InitializeIPCBuf();
}
