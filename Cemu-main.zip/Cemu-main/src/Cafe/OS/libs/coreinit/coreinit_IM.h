#pragma once

namespace coreinit
{
	void InitializeIM();
};