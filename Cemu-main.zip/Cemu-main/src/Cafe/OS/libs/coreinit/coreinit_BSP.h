namespace coreinit
{
	void InitializeBSP();
};