
namespace avm
{
	void Initialize();
}