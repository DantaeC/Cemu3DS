void GamePatch_scan();
bool GamePatch_IsNonReturnFunction(uint32 hleIndex);